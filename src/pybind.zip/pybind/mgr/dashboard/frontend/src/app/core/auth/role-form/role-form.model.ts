export class RoleFormModel {
  name: string;
  description: string;
  scopes_permissions: any;
}
