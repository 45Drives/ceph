// -*- mode:C++; tab-width:8; c-basic-offset:2; indent-tabs-mode:t -*-

#pragma once
#include "include/common_fwd.h"

namespace TOPNSPC::common {
  class ConfigProxy;
}
using TOPNSPC::common::ConfigProxy;
